BẢO ANH VŨ — HƯỚNG DẪN CÀI ĐẶT
================================

Đây là website mẫu có giao diện đăng nhập, tạo nick bằng username + mật khẩu, tải ảnh lên và xem/xóa/tải ảnh xuống. Mỗi tài khoản có thư mục ảnh riêng theo Firebase UID.

LƯU Ý QUAN TRỌNG
- Website CHƯA chạy hoàn chỉnh cho đến khi bạn tạo và kết nối một dự án Firebase.
- Không cần Gmail để ĐĂNG NHẬP VÀO WEBSITE, nhưng bước tạo/cấu hình dự án Firebase có thể yêu cầu tài khoản Google của người thiết lập.
- Firebase Authentication sẽ dùng username được chuyển thành địa chỉ nội bộ dạng username@login.baoanhvu.invalid. Không cần nhận email. Đây là cách làm tiện cho bản demo, không phải hệ thống username tùy biến hoàn hảo.
- Không dùng mật khẩu quan trọng đang dùng ở nơi khác.
- Đừng tải ảnh nhạy cảm lên. Người quản lý dự án Firebase có quyền quản trị dữ liệu. Bật quy tắc bảo mật đúng như bên dưới.

PHẦN 1 — TẠO FIREBASE
1. Mở https://console.firebase.google.com/ và tạo project tên bao-anh-vu.
2. Trong Build > Authentication > Get started.
3. Mở Sign-in method, bật Email/Password.
4. Trong Project settings > General > Your apps, bấm biểu tượng Web (</>) để đăng ký app.
5. Sao chép firebaseConfig mà Firebase hiển thị.
6. Mở index.html bằng trình soạn thảo văn bản, tìm đoạn:
   const firebaseConfig = { ... }
   Thay các giá trị PASTE_... bằng giá trị thật của dự án Firebase. Giữ nguyên dấu ngoặc và dấu phẩy.

PHẦN 2 — BẬT LƯU TRỮ ẢNH
1. Vào Build > Storage và bấm Get started.
2. Tạo Storage bucket theo hướng dẫn của Firebase.
3. Mở Storage > Rules, thay rules bằng:

rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{allPaths=**} {
      allow read, write: if request.auth != null
                         && request.auth.uid == userId
                         && request.resource.size < 15 * 1024 * 1024;
    }
  }
}

LƯU Ý: Quy tắc ở trên cho phép đọc/ghi chỉ trong thư mục của chính tài khoản. Tuy nhiên, quy tắc có request.resource khi xóa có thể gây lỗi vì xóa không có request.resource. Dùng phiên bản này thay thế để hỗ trợ upload, đọc và xóa an toàn hơn:

rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{fileName} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow create, update: if request.auth != null
                            && request.auth.uid == userId
                            && request.resource.size < 15 * 1024 * 1024
                            && request.resource.contentType.matches('image/.*');
      allow delete: if request.auth != null && request.auth.uid == userId;
    }
  }
}

Bản website tạo tên file không chứa dấu / bên trong nên rule {fileName} là phù hợp. Bấm Publish để lưu quy tắc.

PHẦN 3 — CHẠY THỬ
- Mở index.html trong trình duyệt sau khi đã điền cấu hình.
- Nhập nick chỉ gồm chữ không dấu, số, _ hoặc -, dài 3–24 ký tự.
- Mật khẩu tối thiểu 6 ký tự.
- Bấm “Tạo nick mới” để tạo tài khoản; lần sau dùng “Đăng nhập”.
- Tải ảnh lên; đăng xuất; đăng nhập bằng nick khác để kiểm tra kho ảnh tách biệt.

PHẦN 4 — ĐƯA LÊN INTERNET MIỄN PHÍ BẰNG GITHUB PAGES
1. Tạo tài khoản tại https://github.com/
2. Tạo repository tên my-photo-site.
3. Tải index.html lên repository (Add file > Upload files) và commit.
4. Mở Settings > Pages.
5. Chọn Deploy from a branch, branch main, folder /(root), rồi Save.
6. Đợi vài phút và mở đường dẫn Pages GitHub hiển thị.

LƯU Ý VỀ CHI PHÍ / GIỚI HẠN
- GitHub Pages thường miễn phí cho repository public.
- Firebase có hạn mức miễn phí/điều kiện thay đổi theo sản phẩm và thời điểm. Kiểm tra bảng giá và yêu cầu bật billing trong Firebase Console trước khi dùng lâu dài.
- Mã Firebase web config không phải mật khẩu quản trị, nhưng quy tắc bảo mật Storage và giới hạn truy cập phải cấu hình đúng.
- Không đặt secret key của server hoặc mật khẩu quản trị trong HTML.
